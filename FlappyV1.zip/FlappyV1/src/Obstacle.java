public class Obstacle {
    double x, y;
    double width, height;
    double velocity;
    double speed;

    public Obstacle(double x, double y, double width, double height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    public Obstacle() {

    }
}