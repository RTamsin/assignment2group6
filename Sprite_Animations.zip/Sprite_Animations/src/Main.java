import java.awt.Image;
import java.util.ArrayList;
import java.util.List;

public class Main extends GameEngine {

    private AnimatedSprite helicopter;
    private AnimatedSprite coin;
    private AnimatedSprite heart;
    private Image background;
    private int width = 640;
    private int height = 480;


    private int getWindowWidth() {
        return width;
    }

    private int getWindowHeight() {
        return height;
    }

    ArrayList<Cloud> clouds = new ArrayList<>();
    Image[] cloudImages = new Image[8];

    class Cloud {
        int x, y;
        double speed;
        double scale; // New
        Image image;

        public Cloud(int x, int y, double speed, double scale, Image image) {
            this.x = x;
            this.y = y;
            this.speed = speed;
            this.scale = scale;
            this.image = image;
        }
    }

    @Override
    public void init() {
        setWindowSize(640, 480); // Set your desired window size

        for (int i = 0; i < 8; i++) {
            cloudImages[i] = loadImage("resources/Cloud/clouds" + (i + 1) + ".png");
        }

        for (int i = 0; i < 4; i++) {
            int x = (int)(Math.random() * getWindowWidth());
            int y = 10 + (int)(Math.random() * 50);  // stay near top
            double speed = 10 + Math.random() * 40;
            double scale = 0.2 + Math.random() * 0.2;  // scale between 0.4 and 0.7
            Image img = cloudImages[(int)(Math.random() * cloudImages.length)];
            clouds.add(new Cloud(x, y, speed, scale, img));
        }

        background = loadImage("Resources/Background/background3.png");

        Image[] helicopterFrames = {
                loadImage("Resources/Helicopter/helicopter_1.png"),
                loadImage("Resources/Helicopter/helicopter_2.png"),
                loadImage("Resources/Helicopter/helicopter_3.png"),
                loadImage("Resources/Helicopter/helicopter_4.png"),
                loadImage("Resources/Helicopter/helicopter_5.png"),
                loadImage("Resources/Helicopter/helicopter_6.png"),
                loadImage("Resources/Helicopter/helicopter_7.png"),
                loadImage("Resources/Helicopter/helicopter_8.png")
        };
        helicopter = new AnimatedSprite(helicopterFrames, 0.01); // 100ms per frame

        Image[] coinFrames = {
                loadImage("Resources/Coin/coins1.png"),
                loadImage("Resources/Coin/coins2.png"),
                loadImage("Resources/Coin/coins3.png"),
                loadImage("Resources/Coin/coins4.png"),
                loadImage("Resources/Coin/coins5.png"),
                loadImage("Resources/Coin/coins6.png"),
                loadImage("Resources/Coin/coins7.png")
        };
        coin = new AnimatedSprite(coinFrames, 0.10);

        Image[] heartFrames = {
                loadImage("Resources/Heart/heartCleaned.png"),
        };
        heart = new AnimatedSprite(heartFrames, 0.2);
    }

    @Override
    public void update(double dt) {

        for (Cloud cloud : clouds) {
            cloud.x -= cloud.speed * dt;

            int scaledWidth = (int)(cloud.image.getWidth(null) * cloud.scale);

            if (cloud.x + scaledWidth < 0) {
                cloud.x = getWindowWidth() + scaledWidth; // move off-screen to the right
                cloud.y = 10 + (int)(Math.random() * 50);
                cloud.speed = Math.max(10, 10 + Math.random() * 40);
                cloud.scale = 0.2 + Math.random() * 0.2;
                cloud.image = cloudImages[(int)(Math.random() * cloudImages.length)];
            }
        }

        helicopter.update(dt);
        coin.update(dt);
        heart.update(dt);
    }

    @Override
    public void paintComponent() {
        drawImage(background, 0, 0, getWindowWidth(), getWindowHeight());

        for (Cloud cloud : clouds) {
            int scaledWidth = (int)(cloud.image.getWidth(null) * cloud.scale);
            int scaledHeight = (int)(cloud.image.getHeight(null) * cloud.scale);
            drawImage(cloud.image, cloud.x, cloud.y, scaledWidth, scaledHeight);
        }

        drawImage(helicopter.getCurrentFrame(), 100, 200, 100, 64); // Example position
        drawImage(coin.getCurrentFrame(), 300, 200, 32, 32);
        drawImage(heart.getCurrentFrame(), 500, 200, 32, 32);

    }

    public static void main(String[] args) {
        Main game = new Main();
        createGame(game, 30); // 30 FPS
    }
}

